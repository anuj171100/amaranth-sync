export const fileData = [
    { name: 'File A', content: 'Hey Amaranth' },
    { name: 'File B', content: 'Hey Darshat' },
    { name: 'File C', content: 'This is personalized' },
  ];
  